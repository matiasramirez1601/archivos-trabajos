// ==UserScript==
// @name         Anti_Acortador_de_links
// @namespace    http://tampermonkey.net/
// @version      9990.9
// @description  Acortador Hackstore, PelisEnHd y otras paginas de este estilo
// @author       You
// @match        https://hackshort.me/*
// @match        https://drivelinks.me/*
// @match        https://2link.live/*
// @match        https://pelislinks.me/*
// @match        https://atomtt.com/*
// @grant        none
// ==/UserScript==
(function() {
    if (-1 < window.location.href.indexOf("s.php?i=")) {
        var a = location.href.split("s.php?i=");
        if (a && a[1]) {
            a = a[1];
            for (var c = 0; 10 > c; c++) try {
                a = atob(a)
            } catch (f) {
                var d = a.replace(/[a-zA-Z]/g, function (b) {
                    return String.fromCharCode(("Z" >= b ? 90 : 122) >= (b = b.charCodeAt(0) + 13) ? b : b - 26)
                });
                try {
                    new URL(d);
                    var e = !0
                } catch (b) {
                    e = !1
                }
                if (e) {
                    window.location = d;
                    break
                }
            }
        }
    }
})();
